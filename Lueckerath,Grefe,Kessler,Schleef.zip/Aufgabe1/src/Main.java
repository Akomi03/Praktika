public class Main {
    public static void main(String[] args) {
        Zufallszahl z = new Zufallszahl();
        Fakultaet f = new Fakultaet();
        Primzahl p = new Primzahl();
        p.primzahlen();

    }
}
